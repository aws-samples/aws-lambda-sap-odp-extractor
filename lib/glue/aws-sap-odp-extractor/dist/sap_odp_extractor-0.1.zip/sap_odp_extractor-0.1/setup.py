from distutils.core import setup

setup(
    name='sap_odp_extractor',
    version='0.1',
    packages=['extractor'],
    license='MIT'
)